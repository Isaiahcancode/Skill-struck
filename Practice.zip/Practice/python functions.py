
def myfunction():
    global fruit
    fruit = "apple"
  

myfunction()    
print(favorite)
print(fruit)