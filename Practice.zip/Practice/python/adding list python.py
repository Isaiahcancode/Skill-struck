flowers = ["rose", "tulip", "lilac", "sunflower"]

flowers.append("daisys")

flowers.extend(["dafidails", "honeycups"])

flowers.insert(3, "flower")
 
print(flowers)