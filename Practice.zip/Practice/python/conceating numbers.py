string1 = "we have been traveling for up to {1} hours and only saw {0} cars"
hours = 12
cars = 1
print(string1.format(hours,cars))