age = int(input("what is your age"))

license = True
if age >= 16 and license == True:
    print("You are old enough to drive.")
else:
    print("You are not able to drive.")
