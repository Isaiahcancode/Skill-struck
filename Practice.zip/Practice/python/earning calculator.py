earningsgoal = input("how much would you like to save")
print(earningsgoal)