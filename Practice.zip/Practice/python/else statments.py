coins = 10 

if coins > 20:
    print("you have more than enough to buy a puppy") 

elif coins == 20:
    print('you have exactly enough to buy a puppy')
else:
    print('you do not have enough to buy a puppy')
