amount_candy = 30
if amount_candy == 30 or amount_candy > 30:
    print("you win!")
else:
    print("you lose!")