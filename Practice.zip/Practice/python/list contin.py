list = ["marble", "soccer", "baseball", "football", "sports", "games", "maps"]

print(list[2:5])

print(list[0:3:1])

list[3] =  

print(len(list))

