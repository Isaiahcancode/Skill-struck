candy = ["hunter", "brian", "anthony", "tony"]
print(candy)
pieces = [5, 7, 8, 9]
print(pieces)