gross_food = ["mushrooms", "broccoli", "fish"]
for item in gross_food:
    print(item)
if item in gross_food == "mushrooms":
    print("Mushrooms are gross")
elif "broccoli" in gross_food:
    print("broccoli is gross")
elif fish in gross_food:
    print("fish is gross")
else:
    print("is not gross")
