
animals = ["Porcupine", "Hedgehog", "Echidna", "Sea Urchin"]

for animal in animals:
    print(animal + " is the spikiest animal ever!")
