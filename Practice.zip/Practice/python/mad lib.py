
noun1 = input("Choose a noun: ")
pnoun1 = input("Choose a plural noun: ")
noun2 = input("Choose a noun: ")
place = input("Choose a place: ")
adjective = input("Choose an adjective: ")

print("Did you see the " + noun1 + "?")
print("No, I went to see " + pnoun1 + ".")
print("Is that where the " + noun2 + " is?")
print("No, it's in " + place + ".")
print("That sounds " + adjective + "!")
