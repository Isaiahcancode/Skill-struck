lasers = [3, 10, 4, 15, 11,]

print(lasers[2] * 10)
pi = 3.14159265
print(round(pi, 3))

for x in range(0,10):
    print(x)
for y in range(0,10,2):
    print(y)
for z in range(10, 21, 10):
    print(z)