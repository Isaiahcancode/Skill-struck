shapes = ["square", "circle", "rectangle", "triangle", "rombus"]
print(shapes[2])
print(shapes[2] + " is the best shape")