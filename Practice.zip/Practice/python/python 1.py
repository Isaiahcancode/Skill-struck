string1 = "man goes"
string2 = "on a walk"
string3 = "To the store"
string4 = string1 + " " + string2 + " " + string3
print(string4)