caterpillars = 3

leaves = 25

print(caterpillars * leaves)
