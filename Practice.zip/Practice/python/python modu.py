string1 = "we like to code."
print(string1.upper())
string2 = "I can spell"
print(string2.lower())
string3 = "i can't read"
print(string3.replace ("can't", "can"))
string4 = 1
print(string4.upper())