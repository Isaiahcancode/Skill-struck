number = 1

while number <= 500:
    print(number)
    number += 1