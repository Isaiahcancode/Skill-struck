harvest = ["pumpkins", "apples", "corn", "squash", "carrots"]
harvest.remove("squash")
favorite = harvest.pop(1)
print(harvest)