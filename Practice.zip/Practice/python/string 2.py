string1 = "i love coding"
check = "love" in string1
print(check)

#outputs "True"