string1 = "i like to code."
reverse = string1[len(string1)::-1]
print(reverse)
print(string1[4:9])
print(len(string1))
print(string1.rfind("i"))
print(string1.split())
print(string1[-3])