number = int(input("insert number"))
string = str(number)
print(string)